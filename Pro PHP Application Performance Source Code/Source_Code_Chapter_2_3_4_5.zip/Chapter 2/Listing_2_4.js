function addItems(){var items=["Apache","Nginx","Lighty"],node="",i=0,li="";?
node=document.getElementById("webservers");appendList(items,node);}function?
 appendList(items,node){for(i;i<items.length;i++){li=document.createElement("li");?
li.innerHTML=items[i];node.appendChild(li);}}