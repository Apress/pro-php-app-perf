<?php
$username = 'YOUR_USERNAME';
$password = 'YOUR_PASSWORD';
$host     = 'YOUR_HOST';
$dbName   = 'YOUR_DB';

$memHost = 'localhost';
$memPort = 11211;

$memCached = new Memcached();
$memCached->addServer($memHost, $memPort);


if(!$records = $memCached->get('myRecords'))
{
        //Open connection.

        $dbHandler = mysql_connect($host, $username, $password, $dbName) 
                or die('Connection error: '.mysql_error($dbHandler));

        //Connect to db.
        mysql_select_db($dbName, $dbHandler) 
                or die ('Could not connect to db: '.mysql_error($dbHandlder));

        //Fetch the records from the Database.
        $statement = "SELECT num FROM chapter5 ORDER BY num DESC";
        $results   = mysql_query($statement, $dbHandler) 
                or die ('Could not run SQL: '.mysql_error($dbHandler));

        //Close connection.
        mysql_close($dbHandler);

        $records = array();
        while($record = mysql_fetch_object($results))
        {


                $records[] = $record->num;

        }

        //Add the data into Memcached
        $memCached->add('myRecords', $records, 120);
}

//Display
$table = "<table border='1'><tr><td>Array Elements</td></tr>";

foreach($records as $record)
{

        $table .= "<tr><td>$record</td></tr>";

}

$table .= "</table>";

echo $table;
