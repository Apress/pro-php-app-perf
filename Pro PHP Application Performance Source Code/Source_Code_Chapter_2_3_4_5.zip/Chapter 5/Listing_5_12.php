<?php
/**
 * Example visitor counter using Memcached.
 *
 **/
$memHost = 'localhost';
$memPort = 11211;

$memCached = new Memcached();
$memCached->addServer($memHost, $memPort);

if(!$counter = $memCached->get('myCounter'))
{
   $counter = 1;
   //Add the new value to memcached
   $memCached->add('myCounter', $counter, 120);

}
else
{

   $counter++;

   //Update the counter in cache
   $memCached->set('myCounter', $counter, 120);

}

echo "Your visitor number: ".$counter;
