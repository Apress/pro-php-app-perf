<?php
$records = array_fill(0, 10000, 50000);

$table = "<table border='1'><tr><td>Array Elements</td></tr>";

//Display the data.
foreach($records as $record)
{

   $table .= "<tr><td>$record</td></tr>";

}

$table .= "</table>";

echo $table;
