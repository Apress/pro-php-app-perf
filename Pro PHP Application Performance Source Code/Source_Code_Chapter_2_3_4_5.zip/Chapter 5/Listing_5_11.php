<?php
/**
 * Example visitor counter using Memcached.
 *
 **/
$memHost = 'localhost';
$memPort = 11211;

$memCached = new Memcached();
$memCached->addServer($memHost, $memPort);
