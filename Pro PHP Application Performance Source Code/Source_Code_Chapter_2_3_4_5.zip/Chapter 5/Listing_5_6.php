<?php
/**
 * Benchmark Database overhead
 * 
 */
$username = 'YOUR_USERNAME_HERE';
$password = 'YOUR_PASSWORD_HERE';
$host     = 'YOUR_DB_HOST_HERE';
$dbName   = 'YOUR_DATABASE_NAME_HERE';

//Open connection.
$dbHandler = mysql_connect($host, $username, $password, $dbName) 
        or die('Connection error: '.mysql_error($dbHandler));

//Connect to db.
mysql_select_db($dbName, $dbHandler) 
        or die ('Could not connect to db: '.mysql_error($dbHandlder));

//Fetch the records from the Database.
$statement = "SELECT num FROM chapter5 ORDER BY num DESC";
$results   = mysql_query($statement, $dbHandler) 
        or die ('Could not run SQL: '.mysql_error($dbHandler));

//Close connection.
mysql_close($dbHandler);

$records = array_fill(0, 10000, 50000);

$table = "<table border='1'><tr><td>Array Elements</td></tr>";

//Display the data.
foreach($records as $record)
{

   $table .= "<tr><td>$record</td></tr>";

}

$table .= "</table>";

echo $table;
