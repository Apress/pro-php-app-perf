<?php
/**
 * No Database overhead.
 * 
 */
$username = 'YOUR_USERNAME_HERE';
$password = 'YOUR_PASSWORD_HERE';
$host     = 'localhost';
$dbName   = 'pro_php_perf';
 
//Open connection.
$dbHandler = mysql_connect($host, $username, $password, $dbName) 
        or die('Connection error: '.mysql_error($dbHandler));
 
//Connect to db.
mysql_select_db($dbName, $dbHandler) 
        or die ('Could not connect to db: '.mysql_error($dbHandlder));
 
//Fetch the records from the Database.
$statement = "SELECT num FROM chapter5 ORDER BY num DESC";
$results   = mysql_query($statement, $dbHandler) 
        or die ('Could not run SQL: '.mysql_error($dbHandler));
 
//Close connection.
mysql_close($dbHandler);
 
//Add to collection
$records = array();
while($record = mysql_fetch_object($results))
{

        $records[] = $record->num;

}
 
//Display
$table = "<table border='1'><tr><td>Array Elements</td></tr>";

foreach($records as $record)
{

        $table .= "<tr><td>$record</td></tr>";

}

$table .= "</table>";

echo $table;
