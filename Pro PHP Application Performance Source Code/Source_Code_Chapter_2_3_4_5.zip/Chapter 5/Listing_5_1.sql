CREATE DATABASE pro_php_perf;
USE pro_php_perf;
CREATE TABLE chapter5 (num int(8) NOT NULL);
