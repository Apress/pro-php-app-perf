<?php
/**
 * Example visitor counter using APC.
 *
 **/
if(!$counter = apc_fetch('myCounter'))
{
   $counter = 1;
   //Add the new value to memcached
   apc_add('myCounter', $counter, 120);

}
else
{

   $counter++;

   //Update the counter in cache
   apc_store('myCounter', $counter, 120);

}

echo "Your visitor number: ".$counter;
