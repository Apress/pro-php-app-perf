<?php
/**
 * Insert 10,000 random numerical values into table.
 * 
 */
$username = 'YOUR_USERNAME_HERE';
$password = 'YOUR_PASSWORD_HERE';
$host     = 'YOUR_DB_HOST_HERE';
$dbName   = 'YOUR_DATABASE_NAME_HERE';

//Open connection.
$dbHandler = mysqli_connect($host, $username, $password, $dbName) 
        or die('Connection error: '.mysqli_error());

//Connect to db.
mysqli_select_db($dbHandler, $dbName) 
   or die ('Could not connect to db: '.mysqli_error());

//Add in 10000 records into db.
$i=0;
while($i<10000)
{
        //Generate random number
        $num = rand(1,1000000);
        
        //Insert into table
        $statement = "INSERT INTO chapter5 (num) VALUES ($num)";
        mysqli_query($dbHandler, $statement) 
            or die ('Error executing statement: '.mysqli_error());

        ++$i;
}

//Close connection.
mysqli_close($dbHandler);
