<?php
class Person 
{

   public $_gender = NULL;
   public $_age = NULL;

}

$personObj = new Person();

$start = microtime();
for($i=0; $i<100000; $i++)
{
   //Average: 0.0205617ms
   $personObj->_gender;
}

echo microtime()-$start.'ms';
