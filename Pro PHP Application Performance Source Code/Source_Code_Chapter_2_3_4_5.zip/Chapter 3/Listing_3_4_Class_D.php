<?php
class D
{
}