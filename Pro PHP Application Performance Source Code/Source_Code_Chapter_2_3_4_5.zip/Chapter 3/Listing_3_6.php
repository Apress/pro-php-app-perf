<?php
require("ClassA.php");
require("ClassB.php");
require("ClassC.php");
require("ClassD.php");

echo "Only testing require_once.";