<?php
$fileToFetch = "<YOUR_2.3MB_FILE_STORED_LOCALLY>";

$start = microtime();

$fileHandler = fopen($fileToFetch, 'r');
$fileContent = fread($fileHandler, filesize($fileToFetch));


$end = microtime()-$start;
echo $end.'ms<br>';
