<?php
class C
{
}