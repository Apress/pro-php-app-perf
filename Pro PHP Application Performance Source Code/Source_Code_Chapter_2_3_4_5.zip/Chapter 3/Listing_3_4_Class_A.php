<?php
class A
{
}