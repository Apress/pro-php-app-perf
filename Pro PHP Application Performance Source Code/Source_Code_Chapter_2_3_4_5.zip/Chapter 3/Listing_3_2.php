<?php 
$name = "Snoopy Padilla";
echo 'Hi there, '.$name; //Slower
echo "Hi there, $name"; //Faster..slightly