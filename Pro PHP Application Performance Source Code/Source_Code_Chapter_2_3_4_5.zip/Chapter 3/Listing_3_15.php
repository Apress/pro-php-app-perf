<?php
$fileToFetch = "<YOUR_3.9KB_FILE_STORED_LOCALLY>";

//Access the file 100000 times
$start = microtime();

for($i=0; $i<100000; $i++)
{
   $fileHandler = fopen($fileToFetch, 'r');
   $fileContent = fread($fileHandler, filesize($fileToFetch));
}

$end = microtime()-$start;
echo $end.'ms<br>';
