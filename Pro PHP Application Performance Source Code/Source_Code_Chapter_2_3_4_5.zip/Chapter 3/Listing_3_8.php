<?php 
$items = array(1,2,3,4,5,6,7,8,9,10);
$count = count($items);

for($i=0; $i<$count; $i++)
{
   $x = 10031981 * $i;
}