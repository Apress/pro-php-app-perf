<?php
echo "Hi "."there. "."how are "."you?";  //Slow
echo "Hi ","there. ","how are ","you?";  //Faster�slightly
