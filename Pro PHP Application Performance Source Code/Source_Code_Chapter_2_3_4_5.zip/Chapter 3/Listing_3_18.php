<?php
class Person 
{
   private $_gender = NULL;
   private $_age = NULL;

   public function getGender()
   {
      return $this->_gender;
   }

   public function getAge()
   {
      return $this->_age;
   }

   public function setGender($gender)
   {
      $this->_gender = $gender;
   }

   public function setAge($age)
   {
      $this->_age = $age;
   }

}

$personObj = new Person();

$start = microtime();
for($i=0; $i<100000; $i++)
{
   $personObj->getGender();
}
echo microtime()-$start.'ms';
