<?php 
$items = array(1,2,3,4,5,6,7,8,9,10);
for($i=0; $i<count($items); $i++)
{
   $x = 10031981 * $i;  
}