<?php 
$items = array_fill(0, 100000, '12345678910');

$start = microtime();
reset($items);
$i=0;
while($i<100000)
{
   $x = $items[$i];
   $i++;
}
echo microtime()-$start;
