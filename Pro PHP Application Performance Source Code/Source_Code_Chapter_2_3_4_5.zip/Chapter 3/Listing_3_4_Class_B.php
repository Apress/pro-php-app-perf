<?php
class B
{
}