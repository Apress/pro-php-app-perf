<?php 
$items = array_fill(0, 100000, '12345678910');

$start = microtime();
reset($items);
foreach($items as $item)
{
   $x = $item;
}
echo microtime()-$start;
