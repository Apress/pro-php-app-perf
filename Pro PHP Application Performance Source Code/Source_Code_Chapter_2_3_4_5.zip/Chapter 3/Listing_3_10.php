<?php
$items = array(1,2,3,4,5,6,7,8,9,10);
$count = count($items);

$start = microtime();
for($x=0; $x<100000; $x++){
   for($i=0; $i<$count; $i++)
   {
      $j = 100381*$items[$i];
   }
}
echo microtime()-$start;
