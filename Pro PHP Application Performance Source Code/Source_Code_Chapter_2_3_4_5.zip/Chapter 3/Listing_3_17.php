<?php
$fileToFetch = "<YOUR_2.3MB_FILE_STORED_LOCALLY>";

$start = microtime();

$fileContent = file_get_contents($fileToFetch);

$end = microtime()-$start;
echo $end.'ms<br>';
